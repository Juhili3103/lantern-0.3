async function getRealWalkingRoute(start, destination) {
  const coordinates =
    `${start[0]},${start[1]};${destination[0]},${destination[1]}`;

  const url =
    `https://api.mapbox.com/directions/v5/mapbox/walking/${coordinates}` +
    `?alternatives=true&overview=full&geometries=geojson` +
    `&access_token=${mapboxgl.accessToken}`;

  const response = await fetch(url);

  if (!response.ok) {
    throw new Error("Could not get route from Mapbox");
  }

  const data = await response.json();

  if (!data.routes || data.routes.length === 0) {
    throw new Error("No walking route found");
  }

  return data.routes;
}